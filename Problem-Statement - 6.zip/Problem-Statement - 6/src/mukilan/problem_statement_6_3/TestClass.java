package mukilan.problem_statement_6_3;


import java.util.Vector;
public class TestClass {
	public static void main(String[] args) {
		Vector<Employee> v = addInput();
		display(v);
		}

	private static Vector<Employee> addInput() {
		// TODO Auto-generated method stub
		return null;
	}

	private static void display(Vector<Employee> v) {
		// TODO Auto-generated method stub
		
	}

	public static void main1(String[] args) {
		Employee e1=new Employee (123,"jhon", "us");
		Employee e2=new Employee (456,"mike", "london");
		Employee e3=new Employee (789,"kane", "paris");
		Vector<Employee> v=new Vector<Employee>();
		v.add(e1);
		v.add(e2);
		v.add(e3);
		return v;
	}
	public static void main11(String[] args) {
		for(Employee e:v)
		{
			System.out.println(e.getEid()+"\t"+e.getEname()+"\t"+e.getAddress());
		}
	}
}